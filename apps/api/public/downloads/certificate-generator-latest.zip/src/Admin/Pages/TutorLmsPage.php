<?php
declare(strict_types=1);

namespace CertificateGenerator\Admin\Pages;

use CertificateGenerator\Core\Config;
use CertificateGenerator\Database\CustomTables;

/**
 * Tutor LMS course → certificate template mapping admin page.
 */
class TutorLmsPage {

	private string $slug  = 'cg-tutor-lms';
	private string $title = 'Tutor LMS Integration';

	public function register(): void {
		add_submenu_page(
			'cg-dashboard',
			$this->title,
			'Tutor LMS',
			'manage_options',
			$this->slug,
			array( $this, 'render' )
		);
	}

	public function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions', 'certificate-generator' ) );
		}

		global $wpdb;
		$map_table = CustomTables::instance()->get_table( 'lms_course_map' );
		$message   = '';

		if ( isset( $_POST['cg_tutor_save_mapping'] ) && check_admin_referer( 'cg_tutor_save_mapping' ) ) {
			$course_id  = absint( $_POST['course_id'] ?? 0 );
			$template_id = absint( $_POST['template_id'] ?? 0 );
			$trigger    = sanitize_key( $_POST['trigger_event'] ?? 'course_complete' );
			$quiz_id    = absint( $_POST['quiz_id'] ?? 0 );

			if ( $course_id && $template_id && in_array( $trigger, array( 'course_complete', 'quiz_pass', 'both' ), true ) ) {
				$wpdb->query(
					$wpdb->prepare(
						"INSERT INTO $map_table (lms_type, course_id, template_id, trigger_event, quiz_id, enabled)
						 VALUES ('tutor', %d, %d, %s, %d, 1)
						 ON DUPLICATE KEY UPDATE template_id = VALUES(template_id), trigger_event = VALUES(trigger_event),
						 quiz_id = VALUES(quiz_id), enabled = 1",
						$course_id,
						$template_id,
						$trigger,
						$quiz_id ?: null
					)
				);
				$message = 'Mapping saved.';
			} else {
				$message = 'Please choose a course, a template, and a valid trigger.';
			}
		}

		if ( isset( $_GET['cg_tutor_delete'] ) && check_admin_referer( 'cg_tutor_delete_mapping' ) ) {
			$wpdb->delete( $map_table, array( 'id' => absint( $_GET['cg_tutor_delete'] ), 'lms_type' => 'tutor' ) );
			$message = 'Mapping removed.';
		}

		$tutor_active = class_exists( '\TUTOR\Tutor' );
		$flag_on      = Config::flag( 'CG_USE_TUTOR_LMS_INTEGRATION' );

		$courses = $tutor_active
			? get_posts( array( 'post_type' => 'courses', 'post_status' => 'publish', 'numberposts' => -1 ) )
			: array();

		$tpl_table = CustomTables::instance()->get_table( 'certificate_templates' );
		$templates = $wpdb->get_results( "SELECT id, template_name, certificate_type FROM $tpl_table WHERE status = 'published' ORDER BY template_name" );

		$mappings = $wpdb->get_results( "SELECT * FROM $map_table WHERE lms_type = 'tutor' ORDER BY id DESC" );
		?>
		<div class="wrap">
			<h1><?php echo esc_html( $this->title ); ?></h1>

			<?php if ( ! $tutor_active ) : ?>
				<div class="notice notice-warning"><p>Tutor LMS is not active. Install and activate it to map courses.</p></div>
			<?php endif; ?>
			<?php if ( $tutor_active && ! $flag_on ) : ?>
				<div class="notice notice-warning">
					<p>Tutor LMS is active, but auto-issuance is currently <strong>off</strong>. Enable it by adding <code>define( 'CG_USE_TUTOR_LMS_INTEGRATION', true );</code> to <code>wp-config.php</code>. Mappings can still be configured below in the meantime.</p>
				</div>
			<?php endif; ?>
			<?php if ( $message ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $message ); ?></p></div>
			<?php endif; ?>

			<?php if ( $tutor_active ) : ?>
			<div class="card" style="min-height:auto; max-width:700px;">
				<h2>Map a course</h2>
				<form method="post">
					<?php wp_nonce_field( 'cg_tutor_save_mapping' ); ?>
					<table class="form-table">
						<tr>
							<th><label for="course_id">Course</label></th>
							<td>
								<select name="course_id" id="course_id" required>
									<option value="">Select a course…</option>
									<?php foreach ( $courses as $course ) : ?>
										<option value="<?php echo esc_attr( (string) $course->ID ); ?>"><?php echo esc_html( $course->post_title ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
						<tr>
							<th><label for="template_id">Certificate template</label></th>
							<td>
								<select name="template_id" id="template_id" required>
									<option value="">Select a template…</option>
									<?php foreach ( $templates as $tpl ) : ?>
										<option value="<?php echo esc_attr( (string) $tpl->id ); ?>"><?php echo esc_html( $tpl->template_name . ' (' . $tpl->certificate_type . ')' ); ?></option>
									<?php endforeach; ?>
								</select>
								<p class="description">Only published templates are shown. Create one under <strong>Templates</strong> first if empty.</p>
							</td>
						</tr>
						<tr>
							<th><label for="trigger_event">Trigger</label></th>
							<td>
								<select name="trigger_event" id="trigger_event">
									<option value="course_complete">Course completion</option>
									<option value="quiz_pass">Quiz pass</option>
									<option value="both">Course completion OR quiz pass</option>
								</select>
							</td>
						</tr>
						<tr>
							<th><label for="quiz_id">Quiz ID</label></th>
							<td>
								<input type="number" name="quiz_id" id="quiz_id" min="0" class="small-text">
								<p class="description">Required only when trigger includes "quiz pass" — the Tutor quiz post ID.</p>
							</td>
						</tr>
					</table>
					<?php submit_button( 'Save Mapping', 'primary', 'cg_tutor_save_mapping' ); ?>
				</form>
			</div>
			<?php endif; ?>

			<h2>Existing mappings</h2>
			<table class="widefat striped" style="max-width:900px;">
				<thead>
					<tr><th>Course</th><th>Template</th><th>Trigger</th><th>Quiz ID</th><th></th></tr>
				</thead>
				<tbody>
					<?php if ( empty( $mappings ) ) : ?>
						<tr><td colspan="5"><em>No mappings yet.</em></td></tr>
					<?php endif; ?>
					<?php foreach ( $mappings as $row ) : ?>
						<tr>
							<td><?php echo esc_html( get_the_title( (int) $row->course_id ) ?: ( 'Course #' . $row->course_id ) ); ?></td>
							<td>
								<?php
								$tpl_name = $wpdb->get_var( $wpdb->prepare( "SELECT template_name FROM $tpl_table WHERE id = %d", $row->template_id ) );
								echo esc_html( $tpl_name ?: ( 'Template #' . $row->template_id ) );
								?>
							</td>
							<td><?php echo esc_html( $row->trigger_event ); ?></td>
							<td><?php echo esc_html( $row->quiz_id ?: '—' ); ?></td>
							<td>
								<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=' . $this->slug . '&cg_tutor_delete=' . $row->id ), 'cg_tutor_delete_mapping' ) ); ?>"
									onclick="return confirm('Remove this mapping?');">Remove</a>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}
}
