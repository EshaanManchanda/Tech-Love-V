<?php
declare(strict_types=1);

namespace CertificateGenerator\Integrations\TutorLms;

use CertificateGenerator\Database\CustomTables;

/**
 * Resolves a Tutor LMS (course_id, user_id) pair to a Certificate Generator
 * template + student row.
 */
class TutorLmsMapper {

	/**
	 * Find the course → template mapping row for a Tutor course, if one exists and is enabled.
	 */
	public function find_mapping( int $course_id ): ?array {
		global $wpdb;
		$table = CustomTables::instance()->get_table( 'lms_course_map' );
		if ( ! $table ) {
			return null;
		}

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table WHERE lms_type = 'tutor' AND course_id = %d AND enabled = 1 LIMIT 1",
				$course_id
			),
			ARRAY_A
		);

		return $row ?: null;
	}

	/**
	 * certificate_type is what generate_certificate_pdf() actually matches templates on
	 * (see cg_select_certificate_template()) — template_id in the mapping table is only
	 * used to look this string up.
	 */
	public function get_certificate_type_for_template( int $template_id ): ?string {
		global $wpdb;
		$table = CustomTables::instance()->get_table( 'certificate_templates' );
		if ( ! $table ) {
			return null;
		}

		$type = $wpdb->get_var(
			$wpdb->prepare( "SELECT certificate_type FROM $table WHERE id = %d LIMIT 1", $template_id )
		);

		return $type ?: null;
	}

	/**
	 * Find the wp_cg_students row for this WP user by email, or create one from
	 * their WP profile + the Tutor course title. Returns the SQL row array shaped
	 * the same way bulk_import_students() builds it, so it works with the existing
	 * generate_certificate_pdf($post_id=0, $fields, $student_data) SQL-first path.
	 */
	public function resolve_student( int $user_id, int $course_id, string $certificate_type ): ?array {
		$user = get_userdata( $user_id );
		if ( ! $user || ! is_email( $user->user_email ) ) {
			return null;
		}

		global $wpdb;
		$table = CustomTables::instance()->get_table( 'students' );
		if ( ! $table ) {
			return null;
		}

		$existing = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table WHERE email = %s AND certificate_type = %s LIMIT 1",
				$user->user_email,
				$certificate_type
			),
			ARRAY_A
		);
		if ( $existing ) {
			return $existing;
		}

		$student_name = $user->display_name ?: $user->user_login;
		$course_title  = get_the_title( $course_id ) ?: '';
		$issue_date    = current_time( 'Y-m-d' );

		$insert_data = array(
			'student_name'     => sanitize_text_field( $student_name ),
			'email'            => sanitize_email( $user->user_email ),
			'school_name'      => $course_title, // no school concept in Tutor LMS — course title fills the slot
			'certificate_type' => $certificate_type,
			'issue_date'       => $issue_date,
			'year'             => (int) current_time( 'Y' ),
			'status'           => 'active',
			'send_email'       => 1,
			'import_source'    => 'tutor_lms',
			'created_at'       => current_time( 'mysql' ),
			'updated_at'       => current_time( 'mysql' ),
		);

		$wpdb->insert( $table, $insert_data );
		$insert_data['id'] = $wpdb->insert_id;

		return $insert_data;
	}
}
