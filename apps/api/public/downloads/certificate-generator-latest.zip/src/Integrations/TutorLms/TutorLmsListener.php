<?php
declare(strict_types=1);

namespace CertificateGenerator\Integrations\TutorLms;

use CertificateGenerator\Database\CustomTables;
use CertificateGenerator\Email\Mailer;
use CertificateGenerator\Services\EmailService;

/**
 * Reacts to Tutor LMS course/quiz completion and auto-issues a Certificate
 * Generator certificate when the completed course has an enabled mapping.
 *
 * Hooked in Plugin::register_hooks() only when CG_USE_TUTOR_LMS_INTEGRATION
 * is on and Tutor LMS is active.
 */
class TutorLmsListener {

	private TutorLmsMapper $mapper;

	public function __construct( ?TutorLmsMapper $mapper = null ) {
		$this->mapper = $mapper ?? new TutorLmsMapper();
	}

	/**
	 * @see do_action( 'tutor_course_complete_after', $course_id, $user_id )
	 *      models/CourseModel.php:467 in the installed tutor/ plugin.
	 */
	public function handle_course_complete( int $course_id, int $user_id ): void {
		$mapping = $this->mapper->find_mapping( $course_id );
		if ( ! $mapping || ! in_array( $mapping['trigger_event'], array( 'course_complete', 'both' ), true ) ) {
			return;
		}
		$this->issue( $mapping, $user_id, $course_id );
	}

	/**
	 * @see do_action( 'tutor_quiz_finished', $attempt_id, $quiz_id, $user_id )
	 *      classes/Quiz.php:1047 in the installed tutor/ plugin.
	 */
	public function handle_quiz_finished( int $attempt_id, int $quiz_id, int $user_id ): void {
		// \Tutor\Models\QuizModel::get_attempt_result() returns 'pass' | 'fail' | 'pending'
		// (models/QuizModel.php:1683) — self-computes from earned % vs. passing_grade when
		// the attempt row hasn't been finalized yet, so it's safe to call at this point.
		if ( class_exists( '\Tutor\Models\QuizModel' )
			&& \Tutor\Models\QuizModel::get_attempt_result( $attempt_id ) !== \Tutor\Models\QuizModel::RESULT_PASS
		) {
			return;
		}

		global $wpdb;
		$table = CustomTables::instance()->get_table( 'lms_course_map' );
		$mapping = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table WHERE lms_type = 'tutor' AND quiz_id = %d AND enabled = 1
				 AND trigger_event IN ('quiz_pass','both') LIMIT 1",
				$quiz_id
			),
			ARRAY_A
		);
		if ( ! $mapping ) {
			return;
		}
		$this->issue( $mapping, $user_id, (int) $mapping['course_id'] );
	}

	private function issue( array $mapping, int $user_id, int $course_id ): void {
		$certificate_type = $this->mapper->get_certificate_type_for_template( (int) $mapping['template_id'] );
		if ( ! $certificate_type ) {
			error_log( "[CG TutorLMS] Mapped template {$mapping['template_id']} has no certificate_type — skipping issuance." );
			return;
		}

		$student = $this->mapper->resolve_student( $user_id, $course_id, $certificate_type );
		if ( ! $student ) {
			error_log( "[CG TutorLMS] Could not resolve a student record for WP user {$user_id} — skipping issuance." );
			return;
		}

		// Idempotency: skip if this student already has a generated/sent certificate of this type.
		// recipient_email is left blank by the SQL-first (post_id=0) PDF generation path
		// (verified empirically), so match on recipient_name instead — same compound-key
		// tolerance the rest of this plugin already accepts (e.g. bulk-import's upsert-by
		// email+student_name).
		global $wpdb;
		$cert_table = CustomTables::instance()->get_table( 'certificates' );
		$already    = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM $cert_table WHERE recipient_name = %s AND certificate_type = %s AND status != 'failed' LIMIT 1",
				$student['student_name'],
				$certificate_type
			)
		);
		if ( $already ) {
			return;
		}

		if ( ! function_exists( 'generate_certificate_pdf' ) || ! class_exists( '\CG_Field_Schema' ) ) {
			error_log( '[CG TutorLMS] Core certificate functions unavailable — skipping issuance.' );
			return;
		}

		$fields   = \CG_Field_Schema::get_all_renderable_fields( $certificate_type );
		$post_id  = (int) ( $student['wp_post_id'] ?? 0 ); // 0 is expected — Tutor-originated students have no CPT post.
		$file_url = generate_certificate_pdf( $post_id, $fields, $student );

		if ( ! $file_url ) {
			error_log( "[CG TutorLMS] PDF generation failed for {$student['email']} / {$certificate_type}." );
			return;
		}

		if ( (int) $student['send_email'] !== 1 ) {
			return;
		}

		// generate_certificate_pdf() returns a URL; attachments need a filesystem path.
		$pdf_path = wp_normalize_path( str_replace( cg_certificates_url(), cg_certificates_dir(), $file_url ) );
		if ( ! file_exists( $pdf_path ) ) {
			error_log( "[CG TutorLMS] Generated PDF URL did not resolve to a file on disk: {$file_url}" );
			return;
		}

		try {
			$email_service = new EmailService( Mailer::make() );
			$email_service->send_certificate(
				$student['email'],
				$student['student_name'],
				array(
					'certificate_title' => $certificate_type,
					'issue_date'        => $student['issue_date'] ?? current_time( 'mysql' ),
				),
				array( $pdf_path )
			);
		} catch ( \Throwable $e ) {
			error_log( '[CG TutorLMS] Email send failed: ' . $e->getMessage() );
		}
	}
}
